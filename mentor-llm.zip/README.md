# Mentor LLM

Mentor em LLMs rodando com Falcon 7B via Hugging Face Spaces (Gradio).
